package sockets;

public class MainCliente {

	public static void main (String [] args) {
		Cliente cliente = new Cliente();
		cliente.menu();
	}
}
