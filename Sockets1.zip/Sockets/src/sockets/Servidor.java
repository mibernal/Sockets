package sockets;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.net.ServerSocket;


public class Servidor {
	
	
	ServerSocket servidor = null;
	Socket socket = null;
	final int PUERTO = 5000;
	String archivo = "/Users/MiguelBernal/Desktop/datos.txt";
	DataInputStream dataInputStream;
	DataOutputStream dataOutputStream;
	
	public String registrarCuenta(String numeroCuenta, String valor) {
			FileWriter fichero = null;
			PrintWriter printWriter = null;
			try {
				File archivo = new File("datos.txt");
				
				if (!archivo.exists()) {
					archivo.createNewFile();
				}
				
				fichero = new FileWriter(archivo, true);
				printWriter = new PrintWriter(fichero);
				System.out.println("Escribiendo");
				printWriter.println(numeroCuenta + "," + valor);
				return "Registrado OK";
				
			} catch (Exception e) {
					e.printStackTrace();
			} finally {
				try {
						if (null != fichero) {
							fichero.close();
						}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
			return "NO-OK";
	}
			
		public String buscarCuenta(String numeroCuenta) throws FileNotFoundException, IOException {
				String cadena;
				FileReader fileReader = new FileReader(archivo);
				BufferedReader bufferReader = new BufferedReader(fileReader);
				while ((cadena = bufferReader.readLine()) !=null) {
						String datosCuenta[] = cadena.split(",");
						if (datosCuenta[0].equals(numeroCuenta)) {
							return datosCuenta[1];
						}
					}
				
			bufferReader.close();
			return "No se encuentra la Cuenta";
}
				
		public void escucharCliente() {
			
			try {
					servidor = new ServerSocket(PUERTO);
					System.out.println("Servidor Iniciado");
					
					while (true) {
						socket = servidor.accept();
						System.out.println("Cliente Conectado");
						
						dataInputStream = new DataInputStream(socket.getInputStream());
						dataOutputStream = new DataOutputStream(socket.getOutputStream());
						
						String mensaje = dataInputStream.readUTF();
						System.out.println("Datos Enviados Desde el Cliente");
						System.out.println(mensaje);
						
						String datosCuenta[] = mensaje.split(",");
						String resultado;
						
						switch (datosCuenta [0]) {
						
						case "1":
								resultado = registrarCuenta(datosCuenta[1], datosCuenta[2]);		
								dataOutputStream.writeUTF(resultado);
								break;
						case "2":
								String valor = buscarCuenta(datosCuenta[1]);
								resultado = "Valor Cuenta: " + valor;
								dataOutputStream.writeUTF(resultado);
								break;
							
						}
					socket.close();
					
					System.out.println("Cliente Desconectado");
				}
			}	catch	(IOException e) {
					e.printStackTrace();	
			
			}
		}	
}