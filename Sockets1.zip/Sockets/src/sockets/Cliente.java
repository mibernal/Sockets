package sockets;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Cliente {

	final String HOST = "localhost";
	final int PUERTO = 5000;
	Scanner scanner = new Scanner(System.in);
	DataInputStream dataInputStream;
	DataOutputStream dataOutputStream;

	public String capturarDatosCuenta() {
		System.out.println("Ingrese el Numero de Cuenta");
		String cuenta = scanner.next();

		System.out.println("Ingrese el valor ");
		String valor = scanner.next();

		return cuenta + "," + valor;

	}

	public String capturarCuenta() {
		System.out.println("Ingrese el numero de Cuenta");
		return scanner.next();

	}

	public int capturarOpcion() {
		System.out.println("Presione 1 para registrar una cuenta");
		System.out.println("Presione 2 para buscar la cuenta");
		return scanner.nextInt();
	}

	public void menu() {
		System.out.println("Bienvenido");
		System.out.println();

		int opcion = capturarOpcion();
		String mensaje;

		switch (opcion) {

		case 1:
			mensaje = capturarDatosCuenta();
			realizarConexionServidor(opcion, mensaje);
			break;
		case 2:
			mensaje = capturarCuenta();
			realizarConexionServidor(opcion, mensaje);
			break;
		}	
	}


	public void realizarConexionServidor (int opcion, String mensaje) {
	try {
		Socket socket = new Socket(HOST, PUERTO);

		dataInputStream = new DataInputStream(socket.getInputStream());
		dataOutputStream = new DataOutputStream(socket.getOutputStream());

		dataOutputStream.writeUTF(opcion + "," + mensaje);
		mensaje = dataInputStream.readUTF();
		System.out.println(mensaje);
		socket.close();

	}
	catch (IOException e) {
		e.printStackTrace();
	}
	finally {
		System.out.println("Operacion Finalizada"); 

		}
	}
}